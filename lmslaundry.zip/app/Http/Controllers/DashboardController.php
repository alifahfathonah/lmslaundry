<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Crypt;

class DashboardController extends Controller
{
    //
    public function index()
    {
        $orders = DB::table('lms_orders')
                ->select('kode_orders', 'laundry_type','status_order','nama_pelanggan',DB::raw('SUM(total_harga) as totalharga'))
                ->groupBy('kode_orders')
                ->get();

        return view ('dashboard', compact('orders'));
    }
}
